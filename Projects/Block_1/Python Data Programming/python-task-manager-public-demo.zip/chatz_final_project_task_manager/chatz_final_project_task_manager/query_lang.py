from typing import TypedDict, Dict, Optional # standard dictionary w/optional type
from datetime import datetime
from db import run_task_query, run_user_query, run_category_query

class QuerySpec(TypedDict): # shape of dictionary for parse_cmd() return
    entity: Optional[str] # one of three classes or None
    order_by: Optional[str] # column or None
    filters: Dict[str, str] # column and value

def parse_cmd(command: str) -> QuerySpec: # function takes full input and returns QuerySpec shape
    parts = command.strip().split() # takes full input and converts into tokens
    spec: QuerySpec = {
        "entity": None,
        "order_by": None,
        "filters": {}
    }
    if not parts:
        return spec
    spec["entity"] = parts[0].lower() # store entity
    for token in parts[1:]: # loops the tokens after entity
        if token.startswith("o/"):
            spec["order_by"] = token[2:] # store order_by subtract o/
        elif token.startswith("w/"):
            cond = token[2:] # store condition subtract w/
            if "=" in cond: # checks for = sign
                col, value = cond.split("=", 1) # splits column and value from condition only once
                col = col.strip()
                value = value.strip()
                if col in ("start_date", "due_date", "created_at", "completed_at"): # checks for datetime column
                    try:
                        dt = datetime.strptime(value.strip(), "%m/%d/%y")
                        value = dt.date().isoformat() # isoformat is YYYY-MM-DD
                    except ValueError:
                        pass
                spec["filters"][col] = value # store filter
    return spec # return final spec
                # example: "task o/title w/start_date=12/3/25" returns: "tasks", "title", "start_date": "2025-12-03"

def execute_spec(spec: QuerySpec): # function for parsed spec to communicate with database
    entity = spec["entity"]
    order_by = spec["order_by"]
    filters = spec["filters"]
    if entity == "task": # checks entity
        return run_task_query(order_by=order_by, filters=filters) # passes in order_by and filters for database
    if entity == "user":
        return run_user_query(order_by=order_by, filters=filters)
    if entity == "category":
        return run_category_query(order_by=order_by, filters=filters)
    return None # return None if unknown input

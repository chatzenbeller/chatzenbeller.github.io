import db
from query_lang import parse_cmd, execute_spec
from objects import Task, User, Category
from dataclasses import asdict
from datetime import datetime

# BASIC PRINT FUNCTIONS

BANNER_WIDTH = 55

def print_login_line() -> None:
    header = ("[TASK MANAGER LOGIN]")
    line = header.center(BANNER_WIDTH, "_")
    print(line + "\n")

def print_login_menu() -> None:
    print(f"1. Login\n"
          f"2. Exit\n")

def print_enter_username() -> None:
    header = ("[ENTER USERNAME]")
    line = header.center(BANNER_WIDTH, "_")
    print(line + "\n")

def print_enter_password() -> None:
    header = ("[ENTER PASSWORD]")
    line = header.center(BANNER_WIDTH, "_")
    print(line + "\n")

def print_quick_menu() -> None:
    header = ("[QUICK MENU]")
    line = header.center(BANNER_WIDTH, "_")
    print(line)
    print("[1. Display | 2. Add | 3. Edit | 4. Delete | 5. Logout]\n")

def print_display_menu() -> None:
    header = ("[DISPLAY MENU]")
    line = header.center(BANNER_WIDTH, "_")
    print(line + "\n")

def print_add_menu() -> None:
    header = ("[ADD MENU]")
    line = header.center(BANNER_WIDTH, "_")
    print(line + "\n")

def print_edit_menu() -> None:
    header = ("[EDIT MENU]")
    line = header.center(BANNER_WIDTH, "_")
    print(line + "\n")

def print_delete_menu() -> None:
    header = ("[DELETE MENU]")
    line = header.center(BANNER_WIDTH, "_")
    print(line + "\n")

def print_invalid_select() -> None:
    header = ("[INVALID SELECT]")
    line = header.center(BANNER_WIDTH, "_")
    print(line + "\n")

def print_invalid_user() -> None:
    header = ("[INVALID CREDENTIALS]")
    line = header.center(BANNER_WIDTH, "_")
    print(line + "\n")

def print_welcome_user(user) -> None:
    header = (f"[LOGGED IN: {user.username.upper()}]")
    line = header.center(BANNER_WIDTH, "_")
    print(line + "\n")

def print_full_menu() -> None:
    print(f"1. Display\n"
          f"2. Add\n"
          f"3. Edit\n"
          f"4. Delete\n"
          f"5. Logout\n")

def print_input_menu() -> None:
    print(f"Please provide input...\n"
          f"Type Help for advice...\n"
          f"Type Exit to go back...\n")

def print_line() -> None:
    print("_" * BANNER_WIDTH + "\n")

# ADVANCED PRINT NAVIGATION

CURRENT_MENU = None
CURRENT_USER_ID = None
CURRENT_USER = None

def print_help_menu(current_menu) -> None:
    print()
    is_admin = CURRENT_USER is not None and CURRENT_USER.username == "Admin"
    if current_menu == "1":
        if is_admin:
            print("Tables:   Task, Category, User")
        else:
            print("Tables:   Task, Category")
        print(f"Order By: /o\n"
              f"Where:    /w\n"
              f"\n"
              f"Provide the Table you would like to Display...\n"
              f"Optional: Order By\n"
              f"Optional: Where\n"
              f"Example:\n"
              f"\n"
              f"   \"task o/title w/start_date=12/4/25\"\n")
    if current_menu == "2":
        if is_admin:
            print("Tables: Task, Category, User\n")
        else:
            print("Tables: Task, Category\n")
        print(f"Provide the Table you would like to Add...\n")

def check_command_menu() -> None:
    global CURRENT_MENU
    while True:
        print_input_menu()
        command = input()
        if command.lower() == "help":
            print_help_menu(CURRENT_MENU)
            continue
        if command.lower() == "exit":
            print_line()
            return
        spec = parse_cmd(command)
        entity = spec["entity"]
        if entity is None:
            print(f"No table provided.\n")
            continue
        is_admin = CURRENT_USER is not None and CURRENT_USER.username == "Admin"
        entity_list = {"task", "category"}
        if is_admin:
            entity_list.add("user")
        if entity not in entity_list:
            print(f"\n"
                  f"{entity.upper()} is not a valid table.\n")
            continue
        if CURRENT_MENU == "1":
            results = execute_spec(spec)
            if results is None:
                print(f"\n"
                      f"No results for {entity.upper()}.\n")
            else:
                display_menu(entity, results)
        elif CURRENT_MENU == "2":
            if entity == "task":
                add_task_flow()
            elif entity == "category":
                add_category_flow()
            elif entity == "user":
                add_user_flow()
        elif CURRENT_MENU == "3":
            continue
        elif CURRENT_MENU == "4":
            continue

# MENU FUNCTIONS

def display_menu(entity, rows):
    if not rows:
        print(f"\n"
              f"{entity.upper()} table is empty.\n")
        return
    rows = list(rows)
    print(f"\n"
          f"Displaying {entity.upper()} table.\n")
    for obj in rows:
        print_line()
        for key, value in asdict(obj).items():
            print(f"{key}: {value}")
        print_line()

def add_task_flow() -> None:
    global CURRENT_USER_ID
    # TITLE
    while True:
        title = input(f"\n"
                      f"Task Title: ")
        if not title:
            print("\nNo task title provided.")
            continue
        break
# DESCRIPTION
    description = input("Task Description: ")
# IS_RECURRING
    while True:
        recur_raw = input("Is this task recurring? [Y/N]: " ).lower()
        if recur_raw in ("y", "yes"):
            print(f"Task recurring set.\n")
            is_recurring = 1
            break
        elif recur_raw in ("n", "no"):
            is_recurring = 0
            break
        else:
            print("Invalid response...\n")
# CATEGORY
    while True:
        category_name = input("Task Category: ")
        if not category_name:
            print("\nNo category provided.\n")
            continue
        category = db.find_category_name(CURRENT_USER_ID, category_name)
        if category:
            category_id = category.category_id
            print(f"Existing Category: {category.category_name} assigned.\n")
            break
        print(f"\nCategory: {category_name} does not exist.")
        choice = input(f"Would you like to create {category_name} as a new category? [Y/N]: ").lower()
        if choice in ("y", "yes"):
            category_id = db.add_category(CURRENT_USER_ID, category_name)
            print(f"Category: {category_name} created and assigned.\n")
            break
        elif choice in ("n", "no"):
            print(f"Category: {category_name} not assigned.\n")
            continue
        else:
            print("Invalid response...\n")
# START/DUE DATE
    start_date = None
    due_date = None
    set_start_date = input("Would you like to assign a start date to this task? [Y/N]: ").lower()
    while True:
        if set_start_date in ("y", "yes"):
            while True:
                sdate = input("Start Date (MM/DD/YY): ")
                try:
                    start_strp = datetime.strptime(sdate, "%m/%d/%y")
                    start_date = sdate
                    break
                except ValueError:
                    print("Invalid date format (MM/DD/YY)...\n")
            while True:
                ddate = input("Due Date (MM/DD/YY): ")
                try:
                    due_strp = datetime.strptime(ddate, "%m/%d/%y")
                    if due_strp < start_strp:
                        print(f"Due Date cannot be assigned earlier than Start Day ({sdate}).\n")
                        continue
                    due_date = ddate
                    break
                except ValueError:
                    print("Invalid date format (MM/DD/YY)...\n")
            break
        elif set_start_date in ("n", "no"):
            print(f"Start Date not assigned.\n")
            break
        else:
            print("Invalid response...\n")
# RECURRENCE PATTERN
    print(is_recurring)
    recurrence_pattern = ""
    if is_recurring == 1:
        print(f"What is the task recurrence set to?\n"
              f"1. Daily\n"
              f"2. Weekly\n"
              f"3. Monthly\n"
              f"4. Yearly\n")
        while True:
            choice = input("Select [1|2|3|4]: ")
            if choice == "1":
                recurrence_pattern = "Daily"
                print("Recurrence set daily.\n")
                break
            elif choice == "2":
                recurrence_pattern = "Weekly"
                print("Recurrence set weekly.\n")
                break
            elif choice == "3":
                recurrence_pattern = "Monthly"
                print("Recurrence set monthly.\n")
                break
            elif choice == "4":
                recurrence_pattern = "Yearly"
                print("Recurrence set yearly.\n")
                break
            else:
                print("Invalid response...\n")
# PRIORITY
    print(f"What is the task priority?\n"
          f"1. Low\n"
          f"2. Medium\n"
          f"3. High\n")
    while True:
        choice = input("Select [1|2|3]: ")
        if choice == "1":
            priority = 0
            print("Priority set low.\n")
            break
        elif choice == "2":
            priority = 1
            print("Priority set medium.\n")
            break
        elif choice == "3":
            priority = 2
            print("Priority set high.\n")
            break
        else:
            print("Invalid response...\n")
# STATUS
    if start_date or due_date:
        status = 1
    else:
        status = 0
# WRITE TO DB
    task_id = db.add_task(
        user_id=CURRENT_USER_ID,
        category_id=category_id,
        title=title,
        description=description,
        priority=priority,
        start_date=start_date,
        due_date=due_date,
        status=status,
        is_recurring=is_recurring,
        recurrence_pattern=recurrence_pattern)
    print(f"Task {title} created.\n")
    

def add_category_flow() -> None:
    global CURRENT_USER_ID
    while True:
        category_name = input(f"\n"
                              f"Category Name: ")
        if not category_name:
            print(f"\n"
                  f"No category name provided.")
            continue
        category = db.find_category_name(CURRENT_USER_ID, category_name)
        if category:
            print(f"\n"
                  f"Category {category_name} already exists.\n")
            return
        category_id = db.add_category(CURRENT_USER_ID, category_name)
        print(f"\n"
              f"Category {category_name} created.\n")
        return

def add_user_flow() -> None:
    global CURRENT_USER
    is_admin = CURRENT_USER is not None and CURRENT_USER.username == "Admin"
    if not is_admin:
        print(f"\n"
              f"You do not have Admin access to this function.\n")
        return
    while True:
        username = input(f"\n"
                         f"Username: ")
        if not username:
            print("\nNo username provided.")
            continue
        break
    while True:
        password = input("Password: ")
        if not password:
            print("\nNo password provided.\n")
            continue
        break
    try:
        user_id = db.add_user(username, password)
        print(f"\n"
              f"User {username} created.\n")
    except:
        print(f"\n"
              f"Username {username} already exists.\n")

def edit_menu():
    return

def delete_menu():
    return

# INITIAL MENU FUNCTIONS

def main_menu() -> None:
    global CURRENT_MENU
    while True:
        print_full_menu()
        menu_select = input()
        CURRENT_MENU = menu_select
        if menu_select == "1":
            print_display_menu()
            check_command_menu()
        elif menu_select == "2":
            print_add_menu()
            check_command_menu()
        elif menu_select == "3":
            print_edit_menu()
            check_command_menu()
        elif menu_select == "4":
            print_delete_menu()
            check_command_menu()
        elif menu_select == "5":
            CURRENT_MENU = None
            login_menu()
        else:
            CURRENT_MENU = None
            print_invalid_select()

def login_menu() -> None:
    global CURRENT_USER_ID, CURRENT_USER
    print_login_line()
    while True:
        print_login_menu()
        menu_select = input()
        if menu_select == "1":
            print_enter_username()
            username = input()
            print_enter_password()
            password = input()
            user = db.get_login_credentials(username, password)
            if user is None:
                print_invalid_user()
                continue
            CURRENT_USER = user
            CURRENT_USER_ID = user.user_id
            print_welcome_user(user)
            main_menu()
            return
        elif menu_select == "2":
            print("Exiting Program")
            raise SystemExit
        else:
            print_invalid_select()

def main() -> None:
    db.connect()
    db.init_db()
    db.init_admin()
    try:
        login_menu()
    finally:
        db.close()

if __name__ == "__main__":
    main()

import sqlite3
from datetime import date, datetime
from typing import List
from objects import Task, User, Category

# DATABASE CONNECT / CREATE

conn = None

def connect():
    global conn
    if conn is None:
        conn = sqlite3.connect("tasks_db.sqlite")
        conn.row_factory = sqlite3.Row
    return conn

def close():
    global conn
    if conn:
        conn.close()
        conn = None

def init_db():
    c = connect().cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS User (
                    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL UNIQUE,
                    password_hash TEXT NOT NULL
                 );''')
    c.execute('''CREATE TABLE IF NOT EXISTS Category (
                    category_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    category_name TEXT NOT NULL,
                    UNIQUE (user_id, category_name),
                    FOREIGN KEY (user_id) REFERENCES User(user_id)
                 );''')
    c.execute('''CREATE TABLE IF NOT EXISTS Task (
                    task_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    category_id INTEGER NOT NULL,
                    title TEXT NOT NULL,
                    description TEXT,
                    priority INTEGER NOT NULL DEFAULT 0,
                    start_date TEXT,
                    due_date TEXT,
                    created_at TEXT NOT NULL DEFAULT (CURRENT_DATE),
                    completed_at TEXT,
                    status INTEGER NOT NULL DEFAULT 0,
                    is_recurring INTEGER NOT NULL DEFAULT 0,
                    recurrence_pattern TEXT,
                    FOREIGN KEY (user_id) REFERENCES User(user_id),
                    FOREIGN KEY (category_id) REFERENCES Category(category_id)
                 );''')
    connect().commit()
    _load_column_sets()

def init_admin():
    c = connect().cursor()
    c.execute('''INSERT OR IGNORE INTO User (
                    username,
                    password_hash
                 )
                 VALUES (
                    'Admin',
                    'public-demo-only'
                 );''')
    connect().commit()

# PARSE DATE INPUT

def _parse_date(val: str | None):
    if val is None:
        return None
    try:
        return date.fromisoformat(val)
    except ValueError:
        return None

def _to_isoformat(mdY: str | None) -> str | None:
    if not mdY:
        return None
    try:
        dt = datetime.strptime(mdY, "%m/%d/%y")
        return dt.date().isoformat()
    except ValueError:
        return None

# ASSIGN ROW TO OBJECT VARIABLES

def _row_to_task(row):
    return Task(
        task_id=row["task_id"],
        user_id=row["user_id"],
        category_id=row["category_id"],
        title=row["title"],
        description=row["description"],
        priority=row["priority"],
        start_date=_parse_date(row["start_date"]),
        due_date=_parse_date(row["due_date"]),
        created_at=_parse_date(row["created_at"]) or date.today(),
        completed_at=_parse_date(row["completed_at"]),
        status=row["status"],
        is_recurring=bool(row["is_recurring"]),
        recurrence_pattern=row["recurrence_pattern"] or ""
    )

def _row_to_user(row):
    return User(
        user_id=row["user_id"],
        username=row["username"],
        password_hash=row["password_hash"]
    )

def _row_to_category(row):
    return Category(
        category_id=row["category_id"],
        user_id=row["user_id"],
        category_name=row["category_name"]
    )

# ADD TO DATABASE

def find_category_name(user_id: int, name: str) -> Category | None:
    sql = """SELECT * FROM Category
             WHERE user_id = ? AND LOWER(category_name) = LOWER(?)"""
    c = connect().cursor()
    c.execute(sql, (user_id, name))
    row = c.fetchone()
    if row:
        return _row_to_category(row)
    return None

def add_task(user_id: int, category_id: int, title: str,
             description: str = "", priority: int = 0, start_date: str | None = None,
             due_date: str | None = None, status: int = 0, is_recurring: bool = False,
             recurrence_pattern: str = "") -> int:
    start_iso = _to_isoformat(start_date)
    due_iso = _to_isoformat(due_date)
    sql = """INSERT INTO Task (user_id, category_id, title, description, priority, start_date, due_date, status, is_recurring, recurrence_pattern)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""
    c = connect().cursor()
    c.execute(sql, (user_id, category_id, title, description, priority, start_iso, due_iso, status, int(is_recurring), recurrence_pattern))
    connect().commit()
    return c.lastrowid

def add_user(username: str, password: str):
    sql = """INSERT INTO User (username, password_hash)
             VALUES (?, ?)"""
    c = connect().cursor()
    c.execute(sql, (username, password))
    connect().commit()
    return c.lastrowid

def add_category(user_id: int, name: str) -> int:
    sql = """INSERT INTO Category (user_id, category_name)
             VALUES (?, ?)"""
    c = connect().cursor()
    c.execute(sql, (user_id, name))
    connect().commit()
    return c.lastrowid

# LOAD / GET COLUMNS

TASK_COLUMNS: set[str] = set()
USER_COLUMNS: set[str] = set()
CATEGORY_COLUMNS: set[str] = set()

def _load_column_sets():
    global TASK_COLUMNS, USER_COLUMNS, CATEGORY_COLUMNS
    TASK_COLUMNS = get_table_columns("Task")
    USER_COLUMNS = get_table_columns("User")
    CATEGORY_COLUMNS = get_table_columns("Category")

def get_table_columns(table: str) -> set[str]:
    c = connect().cursor()
    c.execute(f"PRAGMA table_info({table})")
    return {row["name"] for row in c.fetchall()}

# QUERIES FOR ALL TABLES

def run_task_query(order_by=None, filters=None) -> List[Task]:
    sql = "SELECT * FROM Task"
    clauses = []
    params = []
    filters = filters or {}
    for col, value in filters.items():
        if col in TASK_COLUMNS:
            clauses.append(f"{col} = ?")
            params.append(value)
    if clauses:
        sql += " WHERE " + " AND ".join(clauses)
    if order_by in TASK_COLUMNS:
        sql += f" ORDER BY {order_by}"
    c = connect().cursor()
    c.execute(sql, params)
    rows = c.fetchall()
    return [_row_to_task(row) for row in rows]

def run_user_query(order_by=None, filters=None) -> List[User]:
    sql = "SELECT * FROM User"
    clauses = []
    params = []
    filters = filters or {}
    for col, value in filters.items():
        if col in USER_COLUMNS:
            clauses.append(f"{col} = ?")
            params.append(value)
    if clauses:
        sql += " WHERE " + " AND ".join(clauses)
    if order_by in USER_COLUMNS:
        sql += f" ORDER BY {order_by}"
    c = connect().cursor()
    c.execute(sql, params)
    rows = c.fetchall()
    return [_row_to_user(row) for row in rows]

def run_category_query(order_by=None, filters=None) -> List[Category]:
    sql = "SELECT * FROM Category"
    clauses = []
    params = []
    filters = filters or {}
    for col, value in filters.items():
        if col in CATEGORY_COLUMNS:
            clauses.append(f"{col} = ?")
            params.append(value)
    if clauses:
        sql += " WHERE " + " AND ".join(clauses)
    if order_by in CATEGORY_COLUMNS:
        sql += f" ORDER BY {order_by}"
    c = connect().cursor()
    c.execute(sql, params)
    rows = c.fetchall()
    return [_row_to_category(row) for row in rows]

# GET LOGIN CREDENTIALS FOR USER

def get_login_credentials(username, password) -> User | None:
    sql = '''SELECT * FROM User
             WHERE username = ? AND password_hash = ?'''
    c = connect().cursor()
    c.execute(sql, (username, password))
    row = c.fetchone()
    if row:
        return _row_to_user(row)
    return None


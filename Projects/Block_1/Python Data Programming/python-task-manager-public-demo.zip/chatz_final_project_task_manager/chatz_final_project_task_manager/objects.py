from dataclasses import dataclass
from datetime import date

@dataclass
class Task:
    task_id:int = 0
    user_id:int = 0
    category_id:int = 0
    title:str = ""
    description:str = ""
    priority:int = 0
    start_date:date | None = None
    due_date:date | None = None
    created_at:date = date.today()
    completed_at:date | None = None
    status:str = ""
    is_recurring:bool = False
    recurrence_pattern:str = ""

@dataclass
class User:
    user_id:int = 0
    username:str = ""
    password_hash:str = ""

@dataclass
class Category:
    category_id:int = 0
    user_id:int = 0
    category_name:str = ""

BEGIN TRANSACTION;

DROP TABLE IF EXISTS User;

DROP TABLE IF EXISTS Category;

DROP TABLE IF EXISTS Task;

CREATE TABLE IF NOT EXISTS User (
    user_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT    NOT NULL
                          UNIQUE,
    password_hash TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS Category (
    category_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL
                          UNIQUE,
    category_name TEXT    NOT NULL,
    UNIQUE (
        user_id,
        category_name
    ),
    FOREIGN KEY (
        user_id
    )
    REFERENCES User (user_id) 
);

CREATE TABLE IF NOT EXISTS Task (
    task_id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id            INTEGER NOT NULL,
    category_id        INTEGER NOT NULL,
    title              TEXT    NOT NULL,
    description        TEXT,
    priority           INTEGER NOT NULL
                               DEFAULT 0,
    start_date         TEXT,
    due_date           TEXT,
    created_at         TEXT    NOT NULL
                               DEFAULT (CURRENT_DATE),
    completed_at       TEXT,
    status             INTEGER NOT NULL
                               DEFAULT 0,
    is_recurring       INTEGER NOT NULL
                               DEFAULT 0,
    recurrence_pattern TEXT,
    FOREIGN KEY (
        user_id
    )
    REFERENCES User (user_id),
    FOREIGN KEY (
        category_id
    )
    REFERENCES Category (category_id) 
);

INSERT INTO User (
                     username,
                     password_hash
                 )
                 VALUES (
                     'Admin',
                     't@skM@nag3r'
                 );

COMMIT ; 

As of right now I'm running out of time and patience with my program
To get started, you will need to login with the Admin account

Admin
t@skM@nag3r

From there you can go into option 1, 2 and 5
Edit and Delete are not coded as of now
---

!!Some of my code jumps around between using numbers from menus and using words

!!Some of my inputs end up being variables that are not translated back to the user as to what they do

---

Accomplishments

- My code uses 4 different .py files to communicate my needs for the task manager

- I have my query_lang.py that uses the typing module to include a dictionary that allows the user to search using keywords in a given string (You can see this by typing HELP in the input dialog when displaying a task; It is very limited though and finicky)

- I have my objects.py that houses my classes for Task, User, and Category

- My db.py which handles my database connections and sql queries

- My task_manager.py which is my UI and the bane of my existence for connecting everything

---

Problems

- My ability to keep track of this project had gotten away from me once I decided to start parsing specific keywords out of a string that users can enter, and when trying to compare user logins

- I think my main problem I had with this project, which I would do over if starting over, is the organization of my functions

- The task_manager.py, objects.py, and db.py to a lesser extent have given me a lot of trouble just trying to understand how they connect and communicate and the way I have structured my code is not very efficient to read through

- I also think I struggled the most with understanding the connection to my class objects